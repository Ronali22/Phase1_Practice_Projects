package com.practice.assignment20;

//You are  a project to work and resolve the diamond problem using OOPs concepts.

/*public class DiamondProblem  extends A extends B{

	//here we are trying to extend two classes at a time
	//which will create compile time error

}*/

class A {

	public void m1() {
		System.out.println("inside A's m1 method");
	}
}

class B {
	public void m1() {
		System.out.println("inside B's m1 method");
	}
}

